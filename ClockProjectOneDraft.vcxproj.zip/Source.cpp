#include <iostream>
#include <string>
#include <cstring>

using namespace std;


string twoDigitString(unsigned int n);
string nCharString(size_t n, char c);
string formatTime24(unsigned int h, unsigned int m, unsigned int s);
string formatTime12(unsigned int h, unsigned int m, unsigned int s);
void printMenu(char* strings[], unsigned int numStrings, unsigned char width);
unsigned int getMenuChoice(unsigned int maxChoice);
void displayClocks(unsigned int h, unsigned int m, unsigned int s);
void addOneHour();
void addOneMinute();
void addOneSecond();
void mainMenu();


unsigned int hour = 0;
unsigned int minute = 0;
unsigned int second = 0;

int main() {
    mainMenu();
    return 0;
}


string twoDigitString(unsigned int n) {
    string str = "";
    if (n < 10) {
        str += "0";
    }
    str += to_string(n);
    return str;
}


string nCharString(size_t n, char c) {
    string str = "";
    for (size_t i = 0; i < n; i++) {
        str += c;
    }
    return str;
}


string formatTime24(unsigned int h, unsigned int m, unsigned int s) {
    string str = "";
    str += twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s);
    return str;
}


string formatTime12(unsigned int h, unsigned int m, unsigned int s) {
    string str = "";
    if (h == 0) {
        str += "12:";
    }
    else if (h < 12) {
        str += twoDigitString(h) + ":";
    }
    else {
        str += twoDigitString(h - 12) + ":";
    }
    str += twoDigitString(m) + ":" + twoDigitString(s);
    if (h < 12) {
        str += " AM";
    }
    else {
        str += " PM";
    }
    return str;
}


void printMenu(char* strings[], unsigned int numStrings, unsigned char width) {
    
    cout << nCharString(width, '*') << endl;

    for (unsigned int i = 0; i < numStrings; ++i) {
        cout << "*" << " " << i + 1 << " - " << strings[i];
        size_t numSpaces = width - (3 + to_string(i).length() + strlen(strings[i]));
        cout << nCharString(numSpaces, ' ') << "*" << endl;

        if (i != numStrings - 1) {
            cout << endl;
        }



    }

    cout << nCharString(width, '*') << endl;

}


unsigned int getMenuChoice(unsigned int maxChoice) {
    unsigned int choice = 0;
    while (choice < 1 || choice > maxChoice) {
        cout << "1 - Add One Hour" << endl;
        cout << "2 - Add One Minute" << endl;
        cout << "3 - Add One Second" << endl;
        cout << "4 - Exit Program" << endl;
        cin >> choice;
    }
    return choice;
}


void displayClocks(unsigned int h, unsigned int m, unsigned int s) {
    cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;
    cout << "*" << nCharString(6, ' ') << "12-HOUR CLOCK" << nCharString(6, ' ') << "*" << nCharString(3, ' ');
    cout << "*" << nCharString(6, ' ') << "24-HOUR CLOCK" << nCharString(6, ' ') << "*" << endl;
    cout << endl;
    cout << "*" << nCharString(6, ' ') << formatTime12(h, m, s) << nCharString(7, ' ') << "*" << nCharString(3, ' ');
    cout << "*" << nCharString(8, ' ') << formatTime24(h, m, s) << nCharString(9, ' ') << "*" << endl;
    cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;
}


void addOneHour() {
    if (hour < 23) {
        hour++;
    }
    else {
        hour = 0;
    }
}


void addOneMinute() {
    if (minute < 59) {
        minute++;
    }
    else {
        minute = 0;
        addOneHour();
    }
}


void addOneSecond() {
    if (second < 59) {
        second++;
    }
    else {
        second = 0;
        addOneMinute();
    }
}


void mainMenu() {
    unsigned int choice = 0;
    while (choice != 4) {
        choice = getMenuChoice(4);
        switch (choice) {
        case 1:
            addOneHour();
            break;
        case 2:
            addOneMinute();
            break;
        case 3:
            addOneSecond();
            break;
        case 4:
            break;
        }
        displayClocks(hour, minute, second);
    }
}